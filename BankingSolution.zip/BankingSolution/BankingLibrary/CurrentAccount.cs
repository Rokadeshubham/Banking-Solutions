﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingLibrary
{
    public class CurrentAccount :Account
    {
        private int overdraftAmount;

        public int OverdraftAmount { get => overdraftAmount; set => overdraftAmount = value; }

        public CurrentAccount(string holderName, double balance, int overdraftAmount) : base(holderName, balance)
        {
            this.overdraftAmount = overdraftAmount;
        }

        public override bool Withdraw(double amount)
        {
            if (amount <= 0)
            {
                throw new NegativeException("Your Current Account balance not less than 0");
            }
            if ((Balance + overdraftAmount) > amount)
            {
                Balance -= amount;
                return true;
            }
            throw new InsufficientFundException(AccountNumber, Balance, amount, (Balance+overdraftAmount));
        }

    }
}
