﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingLibrary
{
    public class SavingAccount:Account
    {
        private double minimumBalance;

        public double MinimumBalance { get => minimumBalance; set => minimumBalance = value; }

        public SavingAccount( string holderName, double balance,double minimumBalance=0):base(holderName,balance)
        {
            this.minimumBalance = minimumBalance;
        }

        public override bool Withdraw(double amount)
        {
            Console.WriteLine("Saving account withdraw");
            if (amount <= 0)
            {
                throw new NegativeException("Your Saving Account balance not less than 0");
            }

            if ((Balance - amount) > minimumBalance)
            {
                Balance -= amount;
                return true;
            }
            throw new InsufficientFundException(AccountNumber, Balance, amount, (Balance - minimumBalance));
           
           
        }
    }
}
