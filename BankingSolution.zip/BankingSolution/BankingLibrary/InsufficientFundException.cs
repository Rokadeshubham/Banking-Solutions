﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingLibrary
{
    class InsufficientFundException:ApplicationException

    {
        private int accountNumber;
        private double balance;
        private double withdrawAmount;
        private double permissibleBalance;
        public InsufficientFundException(int accountNumber,double balance,double withdrawAmount,double permissibleBalance) 
        {
            this.accountNumber = accountNumber;
            this.balance = balance;
            this.withdrawAmount = withdrawAmount;
            this.permissibleBalance = permissibleBalance;



        }

        public override string Message
        {
            get
            {
                StringBuilder message = new StringBuilder();
                message.AppendLine("Your Account "+accountNumber);
                message.AppendLine("has Balance " +balance);
                message.AppendLine("Your trying to withdraw "+withdrawAmount);
                message.AppendLine("But you can withdraw only " + permissibleBalance);
                return message.ToString();
            }
        }
    }
}
