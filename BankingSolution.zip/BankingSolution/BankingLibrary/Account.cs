﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingLibrary
{
    public class Account
    {
        #region Variable
        private static int accountNumberCounter = 1;
        private int accountNumber;
        private string holderName;
        private double balance;
        
        #endregion Variable

        #region Properties
        
        public string HolderName { get => holderName; set => holderName = value; }
        public double Balance { get => balance; set => balance = value; }
        public static int AccountNumberCounter { get => accountNumberCounter; set => accountNumberCounter = value; }
        public int AccountNumber { get => accountNumber; set => accountNumber = value; }
        #endregion Properties

        public bool Deposit(double amount)
        {
            balance += amount;
            return true;
        }

        public virtual bool Withdraw (double amount)
        {
            balance -= amount;
            return true;
        }

        //Constructor

        public Account(string holderName,double balance)
        {
            //this.accountNumber = accountNumber;
            accountNumber = accountNumberCounter++;
            Console.WriteLine(accountNumber);
            this.accountNumber = accountNumberCounter;
            this.holderName = holderName;
            this.balance = balance;
        }
        


    }
}
