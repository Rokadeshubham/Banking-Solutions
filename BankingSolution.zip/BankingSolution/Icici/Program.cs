﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankingLibrary;
namespace Icici
{
    class Program
    {
        static void Main(string[] args)
        {
            //Account a = new Account("Shubh",22222);  
            //a.Deposit(11111);
            //Console.WriteLine(a.Balance);

            try
            {
                SavingAccount sa = new SavingAccount("Sonu", 800000);
                sa.Withdraw(900000);
                Console.WriteLine(sa.Balance);
            }
            catch (Exception e)
            {

                Console.WriteLine(e.Message);
            }

            //Account sa = new SavingAccount( "Neazy", 200000);
            //sa.Withdraw(250000);
            //Console.WriteLine(sa.Balance);

            try
            {
                CurrentAccount ca = new CurrentAccount("Sam", 50000, 2000);
                ca.Withdraw(60000);
                Console.WriteLine(ca.Balance);
            }
            catch (Exception e)
            {

                Console.WriteLine(e.Message);
            }
        }
    }
}
